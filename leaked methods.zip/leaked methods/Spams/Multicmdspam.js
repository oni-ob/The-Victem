const { Authflow } = require("prismarine-auth");
const { RealmAPI } = require("prismarine-realms");
const { createClient } = require("bedrock-protocol");

const REALM_INVITE_CODE = "5iYChWSdjrxdJtg"; 
const SPAM_MESSAGE = "§o§c§lATS OWNS EVERY REALM dsc.gg/ats"; 
const SPAM_COUNT = 50000; 
const RECONNECT_DELAY = 5000; 

const RAINBOW_COLORS = ['§2', '§3', '§4', '§5', '§6', '§d', '§b', '§u', '§9', '§0', '§a'];

async function spamRealm() {
  try {
    const flow = new Authflow("", "auth_cache"); 
    const api = RealmAPI.from(flow, "bedrock");
    console.log();
    
    
    const realm = REALM_INVITE_CODE.length < 10 
      ? await api.getRealm(REALM_INVITE_CODE) 
      : await api.getRealmFromInvite(REALM_INVITE_CODE);
    
    
    console.log("=== [BOT] Realm Info ===");
    console.log(`Name: ${realm.name}`);
    console.log(`ID: ${realm.id}`);
    console.log(`Owner: ${realm.owner}`);
    console.log(`Players: ${realm.players?.length || 0}/${realm.maxPlayers}`);
    console.log(`State: ${realm.state}`);
    console.log(`Expired: ${realm.expired}`);
    console.log(`Days Left: ${realm.daysLeft}`);
    console.log(`Game Version: ${realm.version}`);
    console.log(`Active Version: ${realm.activeVersion}`);
    console.log(`World Type: ${realm.worldType}`);
    console.log("=========================");
    console.log();
    
    console.log(`Joining Realm: ${realm.name} (ID: ${realm.id})`);
    console.log(`Making client now`);
    
    function createAndConnectClient() {
      const client = createClient({
        username: "", // dw
        profilesFolder: "auth_cache",
        realms: { realmId: realm.id },
        skipPing: true, // dw
      });

      client.once("play_status", () => {
        console.log("[BOT] Succesfully Joined the realm now spamming");
        
        console.log();
        for (let i = 0; i < SPAM_COUNT; i++) {
          
          const randomColor = RAINBOW_COLORS[Math.floor(Math.random() * RAINBOW_COLORS.length)];
          const coloredMessage = `${SPAM_MESSAGE}${randomColor}§l!`;
          
          const commands = [
            `/msg @a ${coloredMessage}`,
            `/w @a ${coloredMessage}`,
            `/tell @a ${coloredMessage}`
          ];
          
          for (const command of commands) {
            client.queue("command_request", {
              command: command,
              internal: false,
              version: 76,
              origin: { type: 5, uuid: "0", request_id: "29" },
            });
          }
        }
        console.log();
      });

      client.on("error", (err) => {
        console.error("Client Error:", err.message);
      });

      client.on("close", () => {
        console.log("[BOT] Disconnected from realm. Attempting to reconnect...");
        setTimeout(createAndConnectClient, RECONNECT_DELAY);
      });

      return client;
    }

    createAndConnectClient();

  } catch (err) {
    console.error("Initialization Failed:", err.message);
    console.log(`Retrying in ${RECONNECT_DELAY/1000} seconds...`);
    setTimeout(spamRealm, RECONNECT_DELAY);
  }
}

spamRealm();