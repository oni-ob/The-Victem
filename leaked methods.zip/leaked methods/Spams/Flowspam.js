const { Authflow } = require("prismarine-auth");
const { RealmAPI } = require("prismarine-realms");
const { createClient } = require("bedrock-protocol");

const REALM_INVITE_CODE = "Abx_r7bkltgm7oY"; // realm code yk
const SPAM_MESSAGE = "§4§l     PAY THE FANUM TAX .gg/mh3N369C     §1§l     ATS OWNS ALL REALMS - 2025      §b§l         PAY THE FANUM TAX .gg/mh3N369C     ";
const SPAM_COUNT = 200000; // very op spam last 7373373773years without being in da realm
const RECONNECT_DELAY = 5000; // 5 seconds between reconnection attempts

async function spamRealm() {
  try {
    const flow = new Authflow("", "auth_cache"); // dw abt ts
    const api = RealmAPI.from(flow, "bedrock");
    console.log();
    
    // skibiddi join thing or idk
    const realm = REALM_INVITE_CODE.length < 10 
      ? await api.getRealm(REALM_INVITE_CODE) 
      : await api.getRealmFromInvite(REALM_INVITE_CODE);
    
    // indfo
    console.log("=== [BOT] Realm Info ===");
    console.log(`Name: ${realm.name}`);
    console.log(`ID: ${realm.id}`);
    console.log(`Owner: ${realm.owner}`);
    console.log(`Players: ${realm.players?.length || 0}/${realm.maxPlayers}`);
    console.log(`State: ${realm.state}`);
    console.log(`Expired: ${realm.expired}`);
    console.log(`Days Left: ${realm.daysLeft}`);
    console.log(`Game Version: ${realm.version}`);
    console.log(`Active Version: ${realm.activeVersion}`);
    console.log(`World Type: ${realm.worldType}`);
    console.log("=========================");
    console.log();
    
    console.log(`Joining Realm: ${realm.name} (ID: ${realm.id})`);
    console.log(`Making client now`);
    
    function createAndConnectClient() {
      const client = createClient({
        username: "", // dw
        profilesFolder: "auth_cache",
        realms: { realmId: realm.id },
        skipPing: true, // dw
      });

      client.once("play_status", () => {
        console.log("[BOT] Succesfully Joined the realm now spamming");
        
        // cmd request thingy
        console.log();
        for (let i = 0; i < SPAM_COUNT; i++) {
          client.queue("command_request", {
            command: `/msg LaptopPwn ${SPAM_MESSAGE}`,
            internal: false,
            version: 76,
            origin: { type: 5, uuid: "0", request_id: "29" },
          });
        }
        console.log();
      });

      client.on("error", (err) => {
        console.error("Client Error:", err.message);
      });

      client.on("close", () => {
        console.log("[BOT] Disconnected from realm. Attempting to reconnect...");
        setTimeout(createAndConnectClient, RECONNECT_DELAY);
      });

      return client;
    }

    createAndConnectClient();

  } catch (err) {
    console.error("Initialization Failed:", err.message);
    console.log(`Retrying in ${RECONNECT_DELAY/1000} seconds...`);
    setTimeout(spamRealm, RECONNECT_DELAY);
  }
}

spamRealm();